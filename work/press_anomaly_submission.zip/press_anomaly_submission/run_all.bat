@echo off
REM Windows: 가상환경 생성 -> 패키지 설치 -> 전체 실행
chcp 65001 > nul
cd /d "%~dp0"
if not exist .venv (
  python -m venv .venv
  .venv\Scripts\python -m pip install --upgrade pip
  .venv\Scripts\python -m pip install -r requirements.txt
)
.venv\Scripts\python run_all.py
pause
