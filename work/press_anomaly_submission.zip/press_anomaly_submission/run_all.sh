#!/usr/bin/env bash
# macOS · Linux: 가상환경 생성 → 패키지 설치 → 전체 실행
set -e
cd "$(dirname "$0")"
PY=${PYTHON:-python3}
if [ ! -d .venv ]; then
  "$PY" -m venv .venv
  .venv/bin/python -m pip install --upgrade pip
  .venv/bin/python -m pip install -r requirements.txt
fi
.venv/bin/python run_all.py
